# data_loader.py - 去除CutMix/MixUp，保持原有文件查找逻辑

import os
import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
import albumentations as A
from albumentations.pytorch import ToTensorV2
from PIL import Image
from collections import Counter


class RetinaDataset(Dataset):
    def __init__(self, image_dir, annotation_path=None, transform=None,
                 image_size=256, is_train=True, config=None):
        self.image_dir = image_dir
        self.image_size = image_size
        self.transform = transform
        self.is_train = is_train
        self.config = config

        print(f"📂 图像根目录: {image_dir}")

        # 支持传入单个文件路径或文件列表
        if isinstance(annotation_path, (list, tuple)):
            annotation_files = annotation_path
        else:
            annotation_files = [annotation_path] if annotation_path else []

        # 从所有Excel文件加载标注
        self.image_paths, self.labels = self._load_from_multiple_excels(annotation_files)

        if len(self.image_paths) == 0:
            raise ValueError("没有加载到任何数据！")

        # 🔥 计算并存储类别权重信息（关键改进）
        self.class_counts = self._get_class_counts()
        self.sample_weights = self._compute_sample_weights()

        # 打印统计信息
        self._print_statistics()

    def _get_class_counts(self):
        """获取每个类别的样本数"""
        label_counts = Counter(self.labels)
        # 确保有4个类别
        counts = [label_counts.get(i, 0) for i in range(4)]
        return counts

    def _compute_sample_weights(self):
        """计算采样权重（解决类别不平衡）"""
        total_samples = len(self.labels)

        # 🔥 关键改进：根据您的实际分布计算权重
        # 您的数据分布：0:547, 1:153, 2:246, 3:254
        # 计算逆频率权重
        weights = []
        for count in self.class_counts:
            if count > 0:
                weight = total_samples / (len(self.class_counts) * count)
            else:
                weight = 1.0
            weights.append(weight)

        # 归一化
        weight_sum = sum(weights)
        weights = [w / weight_sum * len(weights) for w in weights]

        # 为每个样本创建权重
        sample_weights = [weights[label] for label in self.labels]
        return sample_weights

    def _print_statistics(self):
        """打印统计信息"""
        total_samples = len(self.image_paths)
        print(f"\n📊 数据统计:")
        print(f"✅ 加载成功: {total_samples} 个样本")
        print(f"📊 类别分布:")
        for i, count in enumerate(self.class_counts):
            percentage = count / total_samples * 100
            weight = self.sample_weights[0] if i == 0 else self.sample_weights[self.labels.index(i)]
            print(f"  类别 {i}: {count} 张 ({percentage:.1f}%), 权重: {weight:.3f}")

        # 计算类别不平衡度
        max_count = max(self.class_counts)
        min_count = min(c for c in self.class_counts if c > 0)
        imbalance_ratio = max_count / min_count
        print(f"📈 类别不平衡度: {imbalance_ratio:.1f}:1")

        if imbalance_ratio > 2.0:
            print(f"⚠️  警告：类别不平衡，已应用加权采样")

    def _load_from_multiple_excels(self, annotation_files):
        """从多个Excel文件加载标注 - 优化版"""
        all_image_paths = []
        all_labels = []

        for annotation_path in annotation_files:
            if not os.path.exists(annotation_path):
                print(f"⚠️  文件不存在: {annotation_path}")
                continue

            print(f"\n📄 处理标注文件: {os.path.basename(annotation_path)}")
            # 从单个文件加载
            image_paths, labels = self._load_single_excel(annotation_path)
            print(f"📊 从 {os.path.basename(annotation_path)} 加载: {len(image_paths)} 个样本")
            all_image_paths.extend(image_paths)
            all_labels.extend(labels)

        return all_image_paths, all_labels

    def _load_single_excel(self, annotation_path):
        """从单个Excel文件加载标注 - 针对您的表格结构优化"""
        image_paths = []
        labels = []

        try:
            # 根据文件扩展名选择合适的引擎
            if annotation_path.lower().endswith('.xlsx'):
                df = pd.read_excel(annotation_path, engine='openpyxl')
            else:
                df = pd.read_excel(annotation_path, engine='xlrd')

            print(f"  文件形状: {df.shape} (行×列)")

            # 🔥 针对您的表格结构：第一列是Image name，第三列是Retinopathy grade
            image_col = 'Image name' if 'Image name' in df.columns else df.columns[0]
            grade_col = 'Retinopathy grade' if 'Retinopathy grade' in df.columns else df.columns[2] if len(
                df.columns) > 2 else df.columns[-1]

            print(f"  使用列: '{image_col}' 作为图像名, '{grade_col}' 作为标签")

            # 显示标签分布
            if grade_col in df.columns:
                grade_counts = df[grade_col].value_counts().sort_index()
                print(f"  标签分布: {dict(grade_counts)}")

            # 处理数据
            for idx, row in df.iterrows():
                img_name = str(row[image_col]).strip()
                if pd.isna(img_name) or not img_name:
                    continue

                # 确保有.tif扩展名
                if not img_name.lower().endswith('.tif'):
                    img_name = img_name + '.tif'

                # 查找图像文件
                img_path = self._find_image_in_base_folders(img_name)
                if not img_path:
                    print(f"⚠️  未找到图像: {img_name}")
                    continue

                # 获取标签
                try:
                    label = int(float(row[grade_col]))
                    if 0 <= label <= 3:
                        image_paths.append(img_path)
                        labels.append(label)
                except Exception as e:
                    print(f"⚠️  提取标签失败 (行{idx + 1}): {e}")
                    continue

        except Exception as e:
            print(f"❌ 读取Excel文件 {annotation_path} 出错: {e}")
            import traceback
            traceback.print_exc()

        return image_paths, labels

    def _find_image_in_base_folders(self, img_name):
        """在Base文件夹中查找图像文件"""
        img_name = str(img_name).strip()

        # 🔥 增强查找逻辑
        if os.path.exists(self.image_dir):
            # 首先尝试精确匹配
            for item in os.listdir(self.image_dir):
                item_path = os.path.join(self.image_dir, item)
                if os.path.isdir(item_path) and item.startswith('Base'):
                    file_path = os.path.join(item_path, img_name)
                    if os.path.exists(file_path):
                        return file_path

            # 如果没有找到，尝试不区分大小写
            img_name_lower = img_name.lower()
            for item in os.listdir(self.image_dir):
                item_path = os.path.join(self.image_dir, item)
                if os.path.isdir(item_path) and item.lower().startswith('base'):
                    for file in os.listdir(item_path):
                        if file.lower() == img_name_lower:
                            return os.path.join(item_path, file)

        return None

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        label = self.labels[idx]

        try:
            # 多种方式尝试读取图像
            try:
                img = Image.open(img_path).convert('RGB')
            except:
                # 尝试用OpenCV读取
                img = cv2.imread(img_path)
                if img is None:
                    raise ValueError(f"OpenCV也无法读取: {img_path}")
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(img)

            img = np.array(img)

            # 验证图像数据
            if img is None or img.size == 0:
                raise ValueError(f"图像读取失败: {img_path}")

            if len(img.shape) == 2:
                img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
            elif img.shape[2] == 4:
                img = cv2.cvtColor(img, cv2.COLOR_RGBA2RGB)
            elif img.shape[2] != 3:
                img = img[:, :, :3]

            # 检查像素值范围
            if img.max() > 255 or img.min() < 0:
                print(f"⚠️  图像像素值异常: {img_path}, range=[{img.min()}, {img.max()}]")
                img = np.clip(img, 0, 255)

            # 应用变换
            if self.transform:
                augmented = self.transform(image=img)
                img = augmented['image']
            else:
                img = cv2.resize(img, (self.image_size, self.image_size))
                img = img.astype(np.float32) / 255.0
                img = torch.from_numpy(img).permute(2, 0, 1)

            label_tensor = torch.tensor(label, dtype=torch.long)

            return img, label_tensor

        except Exception as e:
            print(f"❌ 处理图像出错 {img_path}: {e}")
            # 返回占位图像
            placeholder = torch.zeros((3, self.image_size, self.image_size))
            return placeholder, torch.tensor(label, dtype=torch.long)


def get_enhanced_transforms(image_size=256, is_train=True):
    """获取增强的数据增强变换 - 专门解决过拟合问题"""
    if is_train:
        # 🔥 强化的数据增强策略，专门防止过拟合
        transform_list = [
            A.Resize(image_size, image_size),

            # 几何变换增强
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.3),  # 新增垂直翻转
            A.Rotate(limit=20, p=0.5),  # 增加旋转范围
            A.ShiftScaleRotate(
                shift_limit=0.1,  # 平移
                scale_limit=0.1,  # 缩放
                rotate_limit=15,  # 旋转
                p=0.5
            ),

            # 颜色/对比度增强
            A.RandomBrightnessContrast(
                brightness_limit=0.15,  # 适度增加亮度变化
                contrast_limit=0.15,  # 适度增加对比度变化
                brightness_by_max=True,
                p=0.5
            ),

            # 医学图像特定的增强
            A.OneOf([
                A.CLAHE(clip_limit=2.0, p=0.5),
                A.HueSaturationValue(
                    hue_shift_limit=10,  # 色相微调
                    sat_shift_limit=20,  # 饱和度调整
                    val_shift_limit=10,  # 明度调整
                    p=0.5
                ),
            ], p=0.3),

            # 噪声和模糊增强
            A.OneOf([
                A.GaussNoise(var_limit=(5.0, 30.0), p=0.5),
                A.GaussianBlur(blur_limit=(3, 7), p=0.3),
                A.MedianBlur(blur_limit=5, p=0.2),
            ], p=0.3),

            # 🔥 新增：随机遮挡，防止过拟合的关键技术
            A.CoarseDropout(
                max_holes=8,  # 最大孔洞数
                max_height=image_size // 10,  # 孔洞最大高度
                max_width=image_size // 10,  # 孔洞最大宽度
                min_holes=1,  # 最小孔洞数
                min_height=image_size // 20,  # 孔洞最小高度
                min_width=image_size // 20,  # 孔洞最小宽度
                fill_value=0,  # 填充黑色
                p=0.3  # 应用概率
            ),

            # 标准化
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2(),
        ]

        return A.Compose(transform_list)
    else:
        # 验证集：只有基本预处理
        return A.Compose([
            A.Resize(image_size, image_size),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2(),
        ])


def create_data_loaders(config, batch_size=16):
    """创建数据加载器 - 专门解决过拟合问题，保持原有文件查找逻辑"""
    print("\n" + "=" * 60)
    print("初始化数据加载器（防止过拟合优化）...")

    # 🔥 完全保持原有的文件查找逻辑
    annotation_files = []
    if hasattr(config, 'ANNOTATION_DIR') and os.path.exists(config.ANNOTATION_DIR):
        for file in os.listdir(config.ANNOTATION_DIR):
            if file.lower().endswith('.xls') or file.lower().endswith('.xlsx'):
                annotation_path = os.path.join(config.ANNOTATION_DIR, file)
                annotation_files.append(annotation_path)

    print(f"📄 找到 {len(annotation_files)} 个标注文件:")
    for file in annotation_files:
        print(f"  - {os.path.basename(file)}")

    if not annotation_files:
        raise ValueError("没有找到任何标注文件")

    # 🔥 创建数据集（启用强数据增强）
    print("\n创建数据集（启用强数据增强防止过拟合）...")

    full_dataset = RetinaDataset(
        image_dir=config.IMAGE_DIR,
        annotation_path=annotation_files,
        transform=get_enhanced_transforms(config.IMAGE_SIZE, is_train=True),
        image_size=config.IMAGE_SIZE,
        is_train=True,
        config=config
    )

    # 划分训练集和验证集
    train_size = int(0.8 * len(full_dataset))
    val_size = len(full_dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(
        full_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(config.SEED if hasattr(config, 'SEED') else 42)
    )

    # 🔥 关键改进：创建加权采样器
    print("\n⚖️  创建加权采样器解决类别不平衡...")

    # 获取训练集的权重
    train_indices = train_dataset.indices
    train_weights = [full_dataset.sample_weights[i] for i in train_indices]

    # 创建加权随机采样器
    sampler = WeightedRandomSampler(
        weights=train_weights,
        num_samples=len(train_dataset),
        replacement=True  # 允许重复采样
    )

    # 为验证集设置不同的变换（无增强）
    val_dataset.dataset.transform = get_enhanced_transforms(
        config.IMAGE_SIZE, is_train=False
    )

    # 🔥 根据设备调整参数
    num_workers = 0  # Windows上设为0
    pin_memory = config.DEVICE != 'cpu' and batch_size <= 32

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        sampler=sampler,  # 🔥 使用采样器而不是shuffle
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory
    )

    print(f"\n✅ 数据加载器创建成功（过拟合优化版）")
    print(f"  总样本: {len(full_dataset)}")
    print(f"  训练集: {train_size}")
    print(f"  验证集: {val_size}")
    print(f"  设备: {config.DEVICE}")
    print(f"  使用加权采样器: ✅")
    print(f"  数据增强: 强增强（专门防止过拟合）")

    # 返回类别权重信息
    dataset_info = {
        'class_counts': full_dataset.class_counts,
        'sample_weights': full_dataset.sample_weights[:4],  # 只返回类别权重
        'total_samples': len(full_dataset)
    }

    print(f"📊 类别权重:")
    for i, weight in enumerate(dataset_info['sample_weights']):
        print(f"  类别 {i}: 权重={weight:.3f}")
    print("=" * 60 + "\n")

    return train_loader, val_loader, dataset_info


# 测试函数
def test_dataloader():
    """测试数据加载器"""

    class TestConfig:
        IMAGE_DIR = r"C:\python\pythonProject\.venv\retina_project\images"
        ANNOTATION_DIR = r"C:\python\pythonProject\.venv\retina_project\annotation of images"
        IMAGE_SIZE = 256
        DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
        SEED = 42

    config = TestConfig()

    try:
        print("测试过拟合优化版数据加载器...")
        train_loader, val_loader, dataset_info = create_data_loaders(
            config,
            batch_size=8
        )

        # 测试一个批次
        for batch_idx, batch in enumerate(train_loader):
            if batch_idx >= 2:  # 只看前两个批次
                break
            images, labels = batch
            print(f"批次 {batch_idx + 1}:")
            print(f"  图像形状: {images.shape}")
            print(f"  标签: {labels.tolist()}")

        print("✅ 测试成功！")
        return True

    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    test_dataloader()