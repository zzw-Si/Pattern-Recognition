"""
视网膜病变识别主程序 - Messidor数据库版本
"""

import yaml
import numpy as np
import pandas as pd
from pathlib import Path
import sys
import os

# 添加src目录到Python路径
sys.path.append(str(Path(__file__).parent))

from utils.data_loader import DataLoader
from preprocessing.image_preprocessor import ImagePreprocessor
from feature_extraction.hog_extractor import HOGExtractor
from feature_extraction.pca_extractor import PCAExtractor
from classification.decision_tree import DecisionTreeClassifier
from utils.visualization import ResultVisualizer

class RetinalDiseaseRecognition:
    def __init__(self, config_path='config/config.yaml'):
        """初始化系统"""
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)

        # 创建必要的目录
        self._create_directories()

        # 初始化组件
        self.data_loader = DataLoader(self.config)
        self.preprocessor = ImagePreprocessor(self.config)
        self.hog_extractor = HOGExtractor(self.config)
        self.pca_extractor = PCAExtractor(self.config)
        self.classifier = DecisionTreeClassifier(self.config)
        self.visualizer = ResultVisualizer()

    def _create_directories(self):
        """创建必要的目录"""
        dirs_to_create = [
            self.config['paths']['processed_data'],
            self.config['paths']['features_dir'],
            self.config['paths']['models_dir'],
            self.config['paths']['results_dir']
        ]

        for dir_path in dirs_to_create:
            os.makedirs(dir_path, exist_ok=True)
            print(f"创建目录: {dir_path}")

    def run_full_pipeline(self):
        """运行完整的模式识别流程"""
        print("="*60)
        print("Messidor视网膜病变识别系统 - 开始运行")
        print("="*60)

        # 1. 数据加载
        print("\n1. 数据加载...")
        images, labels, paths = self.data_loader.load_data()
        print(f"   加载完成: {len(images)} 张图片, 标签分布: {np.bincount(labels)}")

        # 2. 数据预处理
        print("\n2. 数据预处理...")
        processed_images = self.preprocessor.process(images)

        # 保存预处理后的图像（如果需要）
        if self.config['preprocessing']['save_processed']:
            save_dir = Path(self.config['paths']['processed_data']) / 'images'
            os.makedirs(save_dir, exist_ok=True)
            self.preprocessor.save_processed_images(processed_images, str(save_dir))

        # 3. 特征提取
        print("\n3. 特征提取...")

        # 方案①: PCA特征提取
        print("   方案①: PCA特征提取...")
        pca_features = self.pca_extractor.extract(processed_images)

        # 保存PCA特征
        pca_feature_path = Path(self.config['paths']['features_dir']) / 'pca_features.npy'
        np.save(pca_feature_path, pca_features)
        print(f"   PCA特征已保存到: {pca_feature_path}")

        # 方案③: HOG + PCA特征提取
        print("   方案③: HOG + PCA特征提取...")
        hog_features = self.hog_extractor.extract(processed_images)
        hog_pca_features = self.pca_extractor.extract(hog_features)

        # 保存HOG+PCA特征
        hog_pca_feature_path = Path(self.config['paths']['features_dir']) / 'hog_pca_features.npy'
        np.save(hog_pca_feature_path, hog_pca_features)
        print(f"   HOG+PCA特征已保存到: {hog_pca_feature_path}")

        # 4. 训练和评估
        print("\n4. 模型训练与评估...")

        # 准备不同的特征集
        feature_sets = {
            'PCA': pca_features,
            'HOG_PCA': hog_pca_features
        }

        results = {}

        for feature_name, features in feature_sets.items():
            print(f"\n   --- 使用特征: {feature_name} ---")

            # 划分训练集和测试集
            from sklearn.model_selection import train_test_split
            X_train, X_test, y_train, y_test = train_test_split(
                features, labels,
                test_size=self.config['experiment']['test_size'],
                random_state=self.config['experiment']['random_state'],
                stratify=labels
            )

            print(f"     训练集: {X_train.shape}, 测试集: {X_test.shape}")

            # 过采样处理（仅在训练集上）
            if self.config['oversampling']['method'] == 'SMOTE':
                from imblearn.over_sampling import SMOTE
                smote = SMOTE(
                    sampling_strategy=self.config['oversampling']['sampling_strategy'],
                    random_state=self.config['oversampling']['random_state']
                )
                X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)
                print(f"     过采样后训练集形状: {X_train_resampled.shape}")
                print(f"     过采样后标签分布: {np.bincount(y_train_resampled)}")
            else:
                X_train_resampled, y_train_resampled = X_train, y_train

            # 训练决策树
            print("     训练决策树模型...")
            self.classifier.train(X_train_resampled, y_train_resampled)

            # 评估模型
            print("     模型评估...")
            metrics = self.classifier.evaluate(X_test, y_test)
            results[feature_name] = metrics

            # 保存模型
            model_path = f"{self.config['paths']['models_dir']}/decision_tree_{feature_name}.pkl"
            self.classifier.save_model(model_path)
            print(f"     模型已保存到: {model_path}")

            # 可视化决策树（如果特征维度不大）
            if features.shape[1] <= 20:
                self.visualizer.plot_decision_tree(
                    self.classifier.model,
                    feature_names=[f'特征{i}' for i in range(features.shape[1])],
                    class_names=['正常', '轻度', '中度', '重度']
                )

        # 5. 结果可视化
        print("\n5. 结果可视化...")
        self.visualizer.plot_results(results)

        # 6. 生成报告
        print("\n6. 生成实验报告...")
        self.generate_report(results, images.shape, labels)

        print("\n" + "="*60)
        print("Messidor视网膜病变识别系统 - 运行完成")
        print("="*60)

    def generate_report(self, results, image_shape, labels):
        """生成详细的实验报告"""
        report_path = f"{self.config['paths']['results_dir']}/experiment_report.txt"

        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("="*70 + "\n")
            f.write("         Messidor视网膜病变识别实验报告\n")
            f.write("="*70 + "\n\n")

            f.write("一、数据集信息\n")
            f.write("-"*40 + "\n")
            f.write(f"数据库: Messidor Diabetic Retinopathy Database\n")
            f.write(f"总样本数: {len(labels)}\n")
            f.write(f"图像原始尺寸: {image_shape[1:]} (H×W)\n")
            f.write(f"预处理后尺寸: {self.config['preprocessing']['target_size']}\n")
            f.write(f"类别分布:\n")
            f.write(f"  0 (正常): {np.sum(labels == 0)}\n")
            f.write(f"  1 (轻度): {np.sum(labels == 1)}\n")
            f.write(f"  2 (中度): {np.sum(labels == 2)}\n")
            f.write(f"  3 (重度): {np.sum(labels == 3)}\n\n")

            f.write("二、实验配置\n")
            f.write("-"*40 + "\n")
            f.write(f"测试集比例: {self.config['experiment']['test_size']*100}%\n")
            f.write(f"过采样方法: {self.config['oversampling']['method']}\n")
            f.write(f"决策树最大深度: {self.config['decision_tree']['max_depth']}\n")
            f.write(f"PCA特征维度: {self.config['feature_extraction']['pca']['n_components']}\n")
            f.write(f"交叉验证折数: {self.config['experiment']['cv_folds']}\n\n")

            f.write("三、特征提取方法\n")
            f.write("-"*40 + "\n")
            f.write("1. PCA特征提取:\n")
            f.write(f"   - 主成分数: {self.config['feature_extraction']['pca']['n_components']}\n")
            f.write(f"   - 白化处理: {self.config['feature_extraction']['pca']['whiten']}\n\n")

            f.write("2. HOG特征提取:\n")
            f.write(f"   - 方向数: {self.config['feature_extraction']['hog']['orientations']}\n")
            f.write(f"   - 像素/单元格: {self.config['feature_extraction']['hog']['pixels_per_cell']}\n")
            f.write(f"   - 单元格/块: {self.config['feature_extraction']['hog']['cells_per_block']}\n")
            f.write(f"   - 块归一化: {self.config['feature_extraction']['hog']['block_norm']}\n\n")

            f.write("四、实验结果\n")
            f.write("-"*40 + "\n")

            for feature_name, metrics in results.items():
                f.write(f"\n特征提取方法: {feature_name}\n")
                f.write(f"-"*30 + "\n")
                f.write(f"准确率: {metrics['accuracy']:.4f}\n")
                f.write(f"精确率: {metrics['precision']:.4f}\n")
                f.write(f"召回率: {metrics['recall']:.4f}\n")
                f.write(f"F1分数: {metrics['f1_score']:.4f}\n")
                f.write(f"交叉验证平均分: {metrics['cv_mean']:.4f} (±{metrics['cv_std']:.4f})\n")

                # 混淆矩阵
                f.write("\n混淆矩阵:\n")
                conf_matrix = metrics['confusion_matrix']
                f.write("     预测\n")
                f.write("     0   1   2   3\n")
                f.write("实   ---------------\n")
                for i in range(4):
                    f.write(f"际 {i} |")
                    for j in range(4):
                        f.write(f" {conf_matrix[i][j]:3d}")
                    f.write("\n")
                f.write("\n")

            f.write("\n五、结论\n")
            f.write("-"*40 + "\n")
            if results:
                best_result = max(results.items(), key=lambda x: x[1]['accuracy'])
                f.write(f"最佳特征提取方法: {best_result[0]}\n")
                f.write(f"最佳准确率: {best_result[1]['accuracy']:.4f}\n")
                f.write(f"最佳F1分数: {best_result[1]['f1_score']:.4f}\n\n")

            f.write("六、参考文献\n")
            f.write("-"*40 + "\n")
            f.write("Decencière et al. Feedback on a publicly distributed database: the Messidor database.\n")
            f.write("Image Analysis & Stereology, v. 33, n. 3, p. 231-234, aug. 2014.\n")
            f.write("Available at: http://dx.doi.org/10.5566/ias.1155\n\n")

            f.write("数据集提供方:\n")
            f.write("Kindly provided by the Messidor program partners\n")
            f.write("(http://www.adcis.net/en/DownloadThirdParty/Messidor.html)\n")

        print(f"   实验报告已保存到: {report_path}")


def main():
    """主函数"""
    try:
        # 运行系统
        system = RetinalDiseaseRecognition()
        system.run_full_pipeline()
    except Exception as e:
        print(f"运行过程中出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()