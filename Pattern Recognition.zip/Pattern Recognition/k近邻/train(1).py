# train.py - K近邻算法实现（修正OpenCV类型错误）

import torch
import numpy as np
import os
import glob
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
import joblib
from PIL import Image
import cv2
from tqdm import tqdm
import warnings

warnings.filterwarnings('ignore')

# 导入配置
from config import config


class KNNRetinopathyClassifier:
    """使用K近邻算法的糖尿病视网膜病变分类器"""

    def __init__(self, config):
        self.config = config
        self.model = None
        self.scaler = StandardScaler()
        self.feature_vectors = []
        self.labels = []
        self.image_paths = []

    def extract_features(self, image):
        """从图像中提取特征 - 修正OpenCV类型错误"""
        features = []

        # 确保图像是uint8类型（0-255范围）
        if image.dtype != np.uint8:
            # 如果是浮点数类型（0-1范围），转换到0-255
            if image.dtype == np.float32 or image.dtype == np.float64:
                image_uint8 = (image * 255).astype(np.uint8)
            else:
                image_uint8 = image.astype(np.uint8)
        else:
            image_uint8 = image

        # 1. 颜色特征（RGB通道的统计特征）
        if len(image_uint8.shape) == 3:  # 彩色图像
            for channel in range(3):
                channel_data = image_uint8[:, :, channel].flatten()
                features.extend([
                    np.mean(channel_data),  # 均值
                    np.std(channel_data),  # 标准差
                    np.median(channel_data),  # 中位数
                    np.max(channel_data),  # 最大值
                    np.min(channel_data),  # 最小值
                    np.percentile(channel_data, 25),  # 25%分位数
                    np.percentile(channel_data, 75),  # 75%分位数
                ])

        # 2. 纹理特征（灰度图像的LBP简化版）
        try:
            # 转换为灰度图
            if len(image_uint8.shape) == 3:
                gray = cv2.cvtColor(image_uint8, cv2.COLOR_RGB2GRAY)
            else:
                gray = image_uint8

            # 尝试使用更简单的纹理特征替代GLCM
            # 计算局部二值模式(LBP)的简化特征
            def simple_lbp_features(img_gray):
                """计算简化的LBP特征"""
                h, w = img_gray.shape
                features = []

                # 计算局部对比度
                kernel_size = 3
                for i in range(1, h - 1):
                    for j in range(1, w - 1):
                        center = img_gray[i, j]
                        neighbors = [
                            img_gray[i - 1, j - 1], img_gray[i - 1, j], img_gray[i - 1, j + 1],
                            img_gray[i, j - 1], img_gray[i, j + 1],
                            img_gray[i + 1, j - 1], img_gray[i + 1, j], img_gray[i + 1, j + 1]
                        ]
                        # 简化的LBP：比较中心像素和邻域平均
                        avg_neighbor = np.mean(neighbors)
                        features.append(1 if center > avg_neighbor else 0)

                # 只计算基本的统计量
                if len(features) > 1000:  # 采样
                    features = features[::len(features) // 1000]

                return np.mean(features), np.std(features)

            lbp_mean, lbp_std = simple_lbp_features(gray)
            features.extend([lbp_mean, lbp_std])

            # 计算图像梯度特征
            sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            gradient_magnitude = np.sqrt(sobelx ** 2 + sobely ** 2)
            features.extend([np.mean(gradient_magnitude), np.std(gradient_magnitude)])

        except Exception as e:
            print(f"⚠️  纹理特征提取出错: {e}")
            features.extend([0, 0, 0, 0])  # 填充默认值

        # 3. 边缘特征（使用Canny边缘检测）
        try:
            edges = cv2.Canny(gray, 50, 150)
            features.append(np.mean(edges))  # 边缘密度
            features.append(np.std(edges))  # 边缘变化
        except:
            features.extend([0, 0])

        # 4. 直方图特征
        try:
            hist, _ = np.histogram(gray.flatten(), bins=16, range=(0, 256))
            hist = hist / hist.sum()  # 归一化
            features.extend(hist[:8])  # 取前8个直方图bin
        except:
            features.extend([0] * 8)

        # 5. 颜色矩（Color Moments）特征
        if len(image_uint8.shape) == 3:
            try:
                # 计算HSV颜色空间的特征
                hsv = cv2.cvtColor(image_uint8, cv2.COLOR_RGB2HSV)
                for channel in range(3):
                    channel_data = hsv[:, :, channel].flatten()
                    # 颜色矩：均值、标准差、偏度
                    mean_val = np.mean(channel_data)
                    std_val = np.std(channel_data)
                    # 简化的偏度计算
                    skewness = np.mean(((channel_data - mean_val) / std_val) ** 3) if std_val > 0 else 0
                    features.extend([mean_val, std_val, skewness])
            except:
                features.extend([0] * 9)  # 3通道 * 3特征

        return np.array(features)

    def load_and_preprocess_image(self, image_path):
        """加载并预处理图像 - 优化版本"""
        try:
            # 加载图像
            image = Image.open(image_path).convert('RGB')

            # 调整大小
            image = image.resize((self.config.IMAGE_SIZE, self.config.IMAGE_SIZE))

            # 转换为numpy数组并确保是uint8类型
            image_np = np.array(image)

            # 归一化到0-1范围（如果需要的话）
            # image_np = image_np / 255.0

            return image_np
        except Exception as e:
            print(f"加载图像 {image_path} 时出错: {e}")
            return None

    def load_dataset(self):
        """加载数据集 - 修复版本"""
        print("📂 开始加载数据集...")

        # 查找所有的Excel文件
        excel_files = glob.glob(os.path.join(self.config.ANNOTATION_DIR, "*.xls"))

        if not excel_files:
            excel_files = glob.glob(os.path.join(self.config.ANNOTATION_DIR, "*.xlsx"))

        if not excel_files:
            # 尝试在annotation目录下查找子目录
            for root, dirs, files in os.walk(self.config.ANNOTATION_DIR):
                for file in files:
                    if file.endswith('.xls') or file.endswith('.xlsx'):
                        excel_files.append(os.path.join(root, file))

        if not excel_files:
            raise FileNotFoundError(f"在 {self.config.ANNOTATION_DIR} 中没有找到Excel文件")

        print(f"📁 找到 {len(excel_files)} 个Excel文件:")
        for f in excel_files:
            print(f"  - {os.path.basename(f)}")

        all_data = []
        total_loaded = 0

        # 读取所有Excel文件
        for excel_file in excel_files:
            try:
                print(f"\n📖 正在读取: {os.path.basename(excel_file)}")
                df = pd.read_excel(excel_file)

                print(f"📊 Excel文件形状: {df.shape}")
                print(f"📋 列名: {list(df.columns)}")

                # 尝试自动识别正确的列名
                possible_name_columns = ['Image name', 'Image Name', 'image_name', 'image', 'Image', '文件名', '图片名']
                possible_grade_columns = ['Retinopathy grade', 'Grade', 'grade', '分类', '类别', 'level', 'Level']

                # 查找图像名列
                image_name_column = None
                for col in possible_name_columns:
                    if col in df.columns:
                        image_name_column = col
                        break

                # 查找分级列
                grade_column = None
                for col in possible_grade_columns:
                    if col in df.columns:
                        grade_column = col
                        break

                if not image_name_column or not grade_column:
                    print(f"⚠️  无法自动识别列名，尝试使用第一列作为图像名，第二列作为分级")
                    # 使用前两列
                    image_name_column = df.columns[0] if len(df.columns) > 0 else None
                    grade_column = df.columns[1] if len(df.columns) > 1 else None

                print(f"✅ 识别到的列: 图像名='{image_name_column}', 分级='{grade_column}'")

                file_loaded_count = 0

                # 提取需要的列
                for idx, row in df.iterrows():
                    try:
                        image_name = str(row[image_name_column])
                        grade = row[grade_column]

                        # 清理图像名（移除可能的扩展名和空格）
                        image_name = image_name.strip()
                        if '.' in image_name:
                            image_name = os.path.splitext(image_name)[0]

                        # 确保grade是整数且在有效范围内
                        try:
                            grade = int(float(grade))
                            if grade not in [0, 1, 2, 3]:
                                print(f"⚠️  第{idx + 1}行: 无效的分级值 {grade}，跳过")
                                continue
                        except (ValueError, TypeError) as e:
                            print(f"⚠️  第{idx + 1}行: 无法解析分级值 '{grade}'，跳过")
                            continue

                        # 查找图像文件 - 多种尝试策略
                        image_found = False
                        image_path = None

                        # 策略1: 直接在IMAGE_DIR下查找
                        for ext in ['.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG', '.bmp', '.BMP']:
                            image_path = os.path.join(self.config.IMAGE_DIR, f"{image_name}{ext}")
                            if os.path.exists(image_path):
                                image_found = True
                                break

                        # 策略2: 在IMAGE_DIR的子目录中查找
                        if not image_found and os.path.exists(self.config.IMAGE_DIR):
                            for root, dirs, files in os.walk(self.config.IMAGE_DIR):
                                for file in files:
                                    # 检查文件名是否包含图像名（不区分大小写）
                                    if image_name.lower() in file.lower():
                                        image_path = os.path.join(root, file)
                                        image_found = True
                                        break
                                if image_found:
                                    break

                        # 策略3: 尝试BaseXX目录结构
                        if not image_found:
                            if os.path.exists(self.config.IMAGE_DIR):
                                try:
                                    base_folders = [d for d in os.listdir(self.config.IMAGE_DIR)
                                                    if os.path.isdir(os.path.join(self.config.IMAGE_DIR, d))
                                                    and d.startswith('Base')]
                                except:
                                    base_folders = []

                                for folder in base_folders:
                                    for ext in ['.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG']:
                                        image_path = os.path.join(self.config.IMAGE_DIR, folder, f"{image_name}{ext}")
                                        if os.path.exists(image_path):
                                            image_found = True
                                            break
                                    if image_found:
                                        break

                        if image_found and image_path:
                            all_data.append({
                                'image_path': image_path,
                                'grade': grade,
                                'image_name': image_name
                            })
                            file_loaded_count += 1
                        else:
                            print(f"⚠️  第{idx + 1}行: 未找到图像文件 {image_name}")

                    except Exception as e:
                        print(f"⚠️  处理第{idx + 1}行时出错: {e}")
                        continue

                print(f"✅ 从 {os.path.basename(excel_file)} 成功加载了 {file_loaded_count} 个样本")
                total_loaded += file_loaded_count

            except Exception as e:
                print(f"❌ 读取文件 {excel_file} 时出错: {e}")
                continue

        if not all_data:
            # 打印调试信息
            print(f"\n🔍 调试信息:")
            print(f"图像目录: {self.config.IMAGE_DIR}")
            print(f"是否存在: {os.path.exists(self.config.IMAGE_DIR)}")

            if os.path.exists(self.config.IMAGE_DIR):
                print(f"目录内容:")
                for item in os.listdir(self.config.IMAGE_DIR)[:10]:  # 只显示前10个
                    item_path = os.path.join(self.config.IMAGE_DIR, item)
                    print(f"  - {item} ({'文件夹' if os.path.isdir(item_path) else '文件'})")

            raise ValueError("没有找到有效的图像-标签对")

        print(f"\n📊 总共加载了 {len(all_data)} 个样本")

        # 统计类别分布
        grade_counts = {}
        for item in all_data:
            grade = item['grade']
            grade_counts[grade] = grade_counts.get(grade, 0) + 1

        print("\n📈 类别分布:")
        for grade in sorted(grade_counts.keys()):
            percentage = grade_counts[grade] / len(all_data) * 100
            print(f"  类别 {grade}: {grade_counts[grade]} 张图像 ({percentage:.1f}%)")

        return all_data

    def extract_all_features(self, data):
        """提取所有图像的特征"""
        print("🔍 开始提取特征...")

        features_list = []
        labels_list = []
        valid_paths = []
        failed_count = 0

        for item in tqdm(data, desc="提取特征"):
            image_path = item['image_path']
            grade = item['grade']

            # 加载和预处理图像
            image = self.load_and_preprocess_image(image_path)
            if image is None:
                failed_count += 1
                continue

            try:
                # 提取特征
                features = self.extract_features(image)

                # 检查特征是否有效
                if np.any(np.isnan(features)) or np.any(np.isinf(features)):
                    print(f"⚠️  无效特征: {image_path}")
                    failed_count += 1
                    continue

                features_list.append(features)
                labels_list.append(grade)
                valid_paths.append(image_path)

            except Exception as e:
                print(f"⚠️  提取特征失败 {image_path}: {e}")
                failed_count += 1
                continue

        if failed_count > 0:
            print(f"⚠️  有 {failed_count} 个样本的特征提取失败")

        if len(features_list) == 0:
            raise ValueError("没有成功提取任何特征")

        self.feature_vectors = np.array(features_list)
        self.labels = np.array(labels_list)
        self.image_paths = valid_paths

        print(f"✅ 特征提取完成，共 {len(self.feature_vectors)} 个样本")
        print(f"📏 特征维度: {self.feature_vectors.shape[1]}")

        return self.feature_vectors, self.labels

    def train_knn(self, n_neighbors=5, weights='distance'):
        """训练KNN模型"""
        print("🚀 开始训练KNN模型...")

        # 检查是否有特征向量
        if len(self.feature_vectors) == 0:
            raise ValueError("请先提取特征或加载数据")

        # 划分训练集和测试集
        X_train, X_test, y_train, y_test, train_paths, test_paths = train_test_split(
            self.feature_vectors, self.labels, self.image_paths,
            test_size=self.config.TEST_SPLIT,
            random_state=self.config.SEED,
            stratify=self.labels
        )

        print(f"📊 数据集划分:")
        print(f"  训练集: {len(X_train)} 个样本")
        print(f"  测试集: {len(X_test)} 个样本")

        # 标准化特征
        print("⚙️ 标准化特征...")
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # 创建并训练KNN模型
        print(f"🤖 创建KNN模型 (n_neighbors={n_neighbors}, weights={weights})...")
        self.model = KNeighborsClassifier(
            n_neighbors=n_neighbors,
            weights=weights,
            algorithm='auto',
            leaf_size=30,
            p=2,  # 欧氏距离
            metric='minkowski',
            n_jobs=-1  # 使用所有可用的CPU核心
        )

        # 训练模型
        self.model.fit(X_train_scaled, y_train)

        # 在训练集和测试集上评估
        print("\n📈 模型评估:")

        # 训练集评估
        y_train_pred = self.model.predict(X_train_scaled)
        train_accuracy = accuracy_score(y_train, y_train_pred)
        print(f"  训练集准确率: {train_accuracy:.4f}")

        # 测试集评估
        y_test_pred = self.model.predict(X_test_scaled)
        test_accuracy = accuracy_score(y_test, y_test_pred)
        print(f"  测试集准确率: {test_accuracy:.4f}")

        # 详细的分类报告
        print("\n📊 详细分类报告 (测试集):")
        print(classification_report(y_test, y_test_pred, target_names=[f'Class {i}' for i in range(4)]))

        # 混淆矩阵
        print("📊 混淆矩阵 (测试集):")
        cm = confusion_matrix(y_test, y_test_pred)
        print(cm)

        # 计算F1分数
        f1 = f1_score(y_test, y_test_pred, average='weighted')
        print(f"  加权F1分数: {f1:.4f}")

        # 保存划分信息用于后续分析
        self.train_test_data = {
            'X_train': X_train_scaled,
            'X_test': X_test_scaled,
            'y_train': y_train,
            'y_test': y_test,
            'train_paths': train_paths,
            'test_paths': test_paths,
            'train_predictions': y_train_pred,
            'test_predictions': y_test_pred,
            'test_accuracy': test_accuracy
        }

        return test_accuracy

    def optimize_k(self, k_range=range(1, 21)):
        """优化K值"""
        print("🔍 开始优化K值...")

        if len(self.feature_vectors) == 0:
            raise ValueError("请先提取特征")

        # 划分训练集和验证集
        X_train, X_val, y_train, y_val = train_test_split(
            self.feature_vectors, self.labels,
            test_size=0.2,
            random_state=self.config.SEED,
            stratify=self.labels
        )

        # 标准化
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_val_scaled = self.scaler.transform(X_val)

        best_k = 1
        best_score = 0
        k_scores = []

        for k in tqdm(k_range, desc="测试不同K值"):
            knn = KNeighborsClassifier(n_neighbors=k, weights='distance', n_jobs=-1)
            knn.fit(X_train_scaled, y_train)
            score = knn.score(X_val_scaled, y_val)
            k_scores.append(score)

            if score > best_score:
                best_score = score
                best_k = k

        print(f"\n✅ K值优化完成:")
        print(f"  最佳K值: {best_k}")
        print(f"  最佳验证准确率: {best_score:.4f}")

        # 绘制K值选择图（如果安装了matplotlib）
        try:
            import matplotlib.pyplot as plt

            plt.figure(figsize=(10, 6))
            plt.plot(k_range, k_scores, 'bo-')
            plt.xlabel('K值')
            plt.ylabel('准确率')
            plt.title('K值选择')
            plt.grid(True)
            plt.axvline(x=best_k, color='r', linestyle='--', label=f'最佳K值={best_k}')
            plt.legend()

            # 保存图像
            os.makedirs(self.config.RESULTS_DIR, exist_ok=True)
            save_path = os.path.join(self.config.RESULTS_DIR, 'knn_k_selection.png')
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"📊 K值选择图已保存到: {save_path}")

        except ImportError:
            print("⚠️  未安装matplotlib，跳过绘图")

        return best_k

    def save_model(self, model_name='knn_retinopathy_model.pkl'):
        """保存模型和Scaler"""
        if self.model is None:
            raise ValueError("模型尚未训练")

        # 创建模型保存目录
        model_dir = os.path.join(self.config.SAVE_DIR, 'knn_models')
        os.makedirs(model_dir, exist_ok=True)

        # 保存模型
        model_path = os.path.join(model_dir, model_name)
        joblib.dump(self.model, model_path)

        # 保存Scaler
        scaler_path = os.path.join(model_dir, 'scaler.pkl')
        joblib.dump(self.scaler, scaler_path)

        # 保存特征信息
        info_path = os.path.join(model_dir, 'model_info.txt')
        with open(info_path, 'w') as f:
            f.write(f"KNN模型信息\n")
            f.write(f"训练时间: {pd.Timestamp.now()}\n")
            f.write(f"特征维度: {self.feature_vectors.shape[1]}\n")
            f.write(f"训练样本数: {len(self.feature_vectors)}\n")
            f.write(f"K值: {self.model.n_neighbors}\n")
            f.write(f"权重方式: {self.model.weights}\n")
            f.write(f"测试集准确率: {self.train_test_data.get('test_accuracy', 'N/A')}\n")

        print(f"💾 模型已保存到: {model_path}")
        print(f"💾 Scaler已保存到: {scaler_path}")

        return model_path


def main():
    """主函数"""
    print("=" * 60)
    print("🤖 K近邻算法 - 糖尿病视网膜病变分类")
    print("=" * 60)

    try:
        # 创建分类器
        classifier = KNNRetinopathyClassifier(config)

        # 1. 加载数据集
        print("\n" + "=" * 60)
        print("📂 加载数据集")
        print("=" * 60)
        data = classifier.load_dataset()

        # 2. 提取特征
        print("\n" + "=" * 60)
        print("🔍 提取特征")
        print("=" * 60)
        features, labels = classifier.extract_all_features(data)

        # 3. 优化K值
        print("\n" + "=" * 60)
        print("🔧 优化K值")
        print("=" * 60)
        best_k = classifier.optimize_k(k_range=range(1, 16))

        # 4. 使用最佳K值训练模型
        print("\n" + "=" * 60)
        print("🚀 使用最佳K值训练模型")
        print("=" * 60)
        accuracy = classifier.train_knn(n_neighbors=best_k, weights='distance')

        # 5. 保存模型
        print("\n" + "=" * 60)
        print("💾 保存模型")
        print("=" * 60)
        model_path = classifier.save_model()

        print("\n" + "=" * 60)
        print("✅ 训练完成!")
        print(f"📊 测试集准确率: {accuracy:.4f}")
        print(f"🔧 最佳K值: {best_k}")
        print(f"💾 模型保存位置: {model_path}")
        print("=" * 60)

    except Exception as e:
        print(f"❌ 训练过程中出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()