# train.py - 修复版ResNet防过拟合（去除L2正则化代码）

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau, CosineAnnealingLR
import torchvision.models as models
import numpy as np
from tqdm import tqdm
import os
import sys
from pathlib import Path
import json
from datetime import datetime
import copy

# 添加项目根目录到路径
sys.path.append(str(Path(__file__).parent))

from config import config
from data_loader import create_data_loaders
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, confusion_matrix, cohen_kappa_score
import matplotlib.pyplot as plt
import seaborn as sns


class RetinaResNet(nn.Module):
    """基于ResNet的视网膜病变分类模型 - 防止过拟合版"""

    def __init__(self, num_classes=4, pretrained=True, model_name='resnet18', dropout_rate=0.5):
        super(RetinaResNet, self).__init__()

        print(f"🏗️  创建{model_name}模型 (dropout={dropout_rate})...")

        # 选择ResNet模型
        if model_name == 'resnet18':
            self.backbone = models.resnet18(pretrained=pretrained)
            in_features = 512
        elif model_name == 'resnet34':
            self.backbone = models.resnet34(pretrained=pretrained)
            in_features = 512
        elif model_name == 'resnet50':
            self.backbone = models.resnet50(pretrained=pretrained)
            in_features = 2048
        elif model_name == 'resnet101':
            self.backbone = models.resnet101(pretrained=pretrained)
            in_features = 2048
        else:
            raise ValueError(f"不支持的模型: {model_name}")

        # 🔥 关键修改：更简单的分类头，增加正则化
        self.backbone.fc = nn.Sequential(
            nn.Dropout(dropout_rate),  # 更高的dropout
            nn.Linear(in_features, 128),  # 减少中间层维度
            nn.BatchNorm1d(128),  # 添加BatchNorm
            nn.ReLU(inplace=True),
            nn.Dropout(dropout_rate * 0.7),  # 第二层dropout
            nn.Linear(128, num_classes)
        )

        # 打印模型信息
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"  总参数: {total_params:,}")
        print(f"  可训练参数: {trainable_params:,}")
        print(f"  ✅ 所有参数均可训练")

    def forward(self, x):
        return self.backbone(x)


class EarlyStopping:
    """早停类"""

    def __init__(self, patience=10, min_delta=0.001, mode='min'):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.mode = mode

    def __call__(self, val_score):
        if self.best_score is None:
            self.best_score = val_score
        elif self.mode == 'min':  # 损失越小越好
            if val_score > self.best_score - self.min_delta:
                self.counter += 1
                if self.counter >= self.patience:
                    self.early_stop = True
            else:
                self.best_score = val_score
                self.counter = 0
        else:  # 准确率越大越好
            if val_score < self.best_score + self.min_delta:
                self.counter += 1
                if self.counter >= self.patience:
                    self.early_stop = True
            else:
                self.best_score = val_score
                self.counter = 0

        return self.early_stop


class Trainer:
    def __init__(self, model, config):
        self.model = model
        self.config = config
        self.device = config.DEVICE

        # 移动到设备
        self.model.to(self.device)
        print(f"📱 模型移动到: {self.device}")

        # 🔥 关键修改：使用标签平滑的交叉熵损失
        print("📊 配置损失函数...")
        # PyTorch 1.10+ 支持label_smoothing，旧版本需要手动实现
        try:
            self.criterion = nn.CrossEntropyLoss(label_smoothing=0.1)  # 🔥 标签平滑
            print(f"  ✅ 使用标签平滑交叉熵损失 (smoothing=0.1)")
        except:
            self.criterion = nn.CrossEntropyLoss()
            print(f"  ⚠️  当前PyTorch版本不支持label_smoothing，使用标准交叉熵")

        # 🔥 关键修改：增加权重衰减
        print("⚙️  配置优化器...")
        self.optimizer = optim.AdamW(
            self.model.parameters(),
            lr=config.LEARNING_RATE,
            weight_decay=0.01,  # 🔥 更高的权重衰减
            betas=(0.9, 0.999)
        )
        print("  使用AdamW优化器 (weight_decay=0.01)")

        # 学习率调度器
        self.scheduler = None

        # 🔥 早停设置
        self.early_stopping = EarlyStopping(
            patience=config.EARLY_STOPPING_PATIENCE,
            min_delta=0.002,
            mode='max'  # 监控准确率
        )

        # 最佳模型跟踪
        self.best_val_acc = 0.0
        self.best_val_loss = float('inf')
        self.best_val_f1 = 0.0
        self.best_model_state = None

        # 类别指标跟踪
        self.best_class_metrics = {i: {'f1': 0.0, 'recall': 0.0} for i in range(4)}

        # 训练历史
        self.history = {
            'train_loss': [], 'train_acc': [], 'train_f1': [],
            'val_loss': [], 'val_acc': [], 'val_f1': [],
            'val_precision': [], 'val_recall': [], 'val_kappa': [],
            'learning_rate': [],
            'epoch_times': [],
            'train_val_gap': [],  # 🔥 新增：训练验证差距
            'class_0_f1': [], 'class_1_f1': [], 'class_2_f1': [], 'class_3_f1': [],
            'class_0_recall': [], 'class_1_recall': [], 'class_2_recall': [], 'class_3_recall': []
        }

        # 创建实验目录
        self.experiment_dir = self._create_experiment_dir()

    def _create_experiment_dir(self):
        """创建实验目录"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        experiment_dir = os.path.join(self.config.SAVE_DIR, f"resnet_nofit_{timestamp}")
        os.makedirs(experiment_dir, exist_ok=True)

        # 保存配置
        config_dict = {}
        for k, v in self.config.__dict__.items():
            if k.startswith('_') or callable(v):
                continue
            if isinstance(v, torch.device):
                config_dict[k] = str(v)
            elif isinstance(v, (torch.Tensor, np.ndarray)):
                config_dict[k] = v.tolist() if hasattr(v, 'tolist') else str(v)
            elif isinstance(v, np.generic):
                config_dict[k] = v.item()
            else:
                config_dict[k] = v

        with open(os.path.join(experiment_dir, 'config.json'), 'w') as f:
            json.dump(config_dict, f, indent=2, ensure_ascii=False)

        print(f"📁 实验目录: {experiment_dir}")
        return experiment_dir

    def train_epoch(self, train_loader):
        """训练一个epoch"""
        self.model.train()
        total_loss = 0
        all_preds = []
        all_labels = []

        pbar = tqdm(train_loader, desc="🚀 训练", leave=False)
        for images, labels in pbar:
            images, labels = images.to(self.device), labels.to(self.device)

            # 清零梯度
            self.optimizer.zero_grad()

            # 前向传播
            outputs = self.model(images)
            loss = self.criterion(outputs, labels)

            # 反向传播
            loss.backward()

            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)  # 🔥 更小的梯度裁剪

            # 更新参数
            self.optimizer.step()

            # 统计
            total_loss += loss.item()
            preds = torch.argmax(outputs, dim=1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

            # 更新进度条
            batch_acc = (preds == labels).float().mean().item()
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'acc': f'{batch_acc:.3f}'
            })

        # 计算指标
        epoch_loss = total_loss / len(train_loader)
        epoch_acc = accuracy_score(all_labels, all_preds)
        epoch_f1 = f1_score(all_labels, all_preds, average='weighted')

        return epoch_loss, epoch_acc, epoch_f1

    def validate(self, val_loader):
        """验证"""
        self.model.eval()
        total_loss = 0
        all_preds = []
        all_labels = []
        class_predictions = {i: [] for i in range(4)}
        class_labels = {i: [] for i in range(4)}

        with torch.no_grad():
            for images, labels in tqdm(val_loader, desc="🧪 验证", leave=False):
                images, labels = images.to(self.device), labels.to(self.device)
                outputs = self.model(images)
                loss = self.criterion(outputs, labels)
                total_loss += loss.item()

                preds = torch.argmax(outputs, dim=1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())

                # 按类别统计
                for i in range(4):
                    class_mask = (labels == i)
                    if class_mask.any():
                        class_predictions[i].extend(preds[class_mask].cpu().numpy())
                        class_labels[i].extend(labels[class_mask].cpu().numpy())

        # 计算总体指标
        val_loss = total_loss / len(val_loader)
        val_acc = accuracy_score(all_labels, all_preds)
        val_f1 = f1_score(all_labels, all_preds, average='weighted', zero_division=0)
        val_precision = precision_score(all_labels, all_preds, average='weighted', zero_division=0)
        val_recall = recall_score(all_labels, all_preds, average='weighted', zero_division=0)
        val_kappa = cohen_kappa_score(all_labels, all_preds)

        # 计算每个类别的指标
        class_metrics = {}
        for class_id in range(4):
            if len(class_labels[class_id]) > 0:
                preds_class = class_predictions[class_id]
                labels_class = class_labels[class_id]

                # 二分类指标
                tp = sum(1 for p, l in zip(preds_class, labels_class) if p == class_id and l == class_id)
                fp = sum(1 for p, l in zip(preds_class, labels_class) if p == class_id and l != class_id)
                fn = sum(1 for p, l in zip(preds_class, labels_class) if p != class_id and l == class_id)

                precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
                f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

                class_metrics[class_id] = {
                    'precision': precision,
                    'recall': recall,
                    'f1': f1,
                    'support': len(class_labels[class_id])
                }
            else:
                class_metrics[class_id] = {
                    'precision': 0.0,
                    'recall': 0.0,
                    'f1': 0.0,
                    'support': 0
                }

        return {
            'loss': val_loss,
            'accuracy': val_acc,
            'f1': val_f1,
            'precision': val_precision,
            'recall': val_recall,
            'kappa': val_kappa,
            'class_metrics': class_metrics
        }

    def _plot_training_history(self):
        """绘制训练历史图表"""
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))

        # 损失曲线
        axes[0, 0].plot(self.history['train_loss'], label='Training Loss', linewidth=2)
        axes[0, 0].plot(self.history['val_loss'], label='Validation Loss', linewidth=2)
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].set_title('Loss Curve')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)

        # 准确率曲线
        axes[0, 1].plot(self.history['train_acc'], label='Training Accuracy', linewidth=2)
        axes[0, 1].plot(self.history['val_acc'], label='Validation Accuracy', linewidth=2)
        axes[0, 1].plot(self.history['train_val_gap'], label='Train-Val Gap', linewidth=1, linestyle='--',
                        alpha=0.7)
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Accuracy')
        axes[0, 1].set_title('Accuracy Curve')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)

        # F1分数曲线
        axes[0, 2].plot(self.history['train_f1'], label='Training F1', linewidth=2)
        axes[0, 2].plot(self.history['val_f1'], label='Validation F1', linewidth=2)
        axes[0, 2].set_xlabel('Epoch')
        axes[0, 2].set_ylabel('F1 Score')
        axes[0, 2].set_title('F1 Score Curve')
        axes[0, 2].legend()
        axes[0, 2].grid(True, alpha=0.3)

        # 各个类别的F1分数曲线
        colors = ['blue', 'green', 'red', 'orange']
        for i in range(4):
            row = 1
            col = i if i < 3 else 2
            axes[row, col].plot(self.history[f'class_{i}_f1'], color=colors[i], linewidth=2)
            axes[row, col].set_xlabel('Epoch')
            axes[row, col].set_ylabel('F1 Score')
            axes[row, col].set_title(f'Class {i} F1 Score')
            axes[row, col].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(os.path.join(self.experiment_dir, 'training_history.png'),
                    dpi=300, bbox_inches='tight')
        plt.close()

    def train(self, train_loader, val_loader):
        """训练循环 - 专门解决过拟合"""
        print(f"\n{'=' * 70}")
        print(f"🎯 开始训练ResNet视网膜病变分类模型 (防过拟合版)")
        print(f"  类别分布: 0:547, 1:153, 2:246, 3:254")
        print(f"  使用策略: 标签平滑 + 更高dropout")
        print(f"{'=' * 70}")

        # 🔥 使用更保守的学习率调度
        self.scheduler = ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=0.5,
            patience=3,
            min_lr=1e-6
        )

        # 打印训练配置
        print(f"\n⚙️  训练配置:")
        print(f"  设备: {self.device}")
        print(f"  训练轮数: {self.config.NUM_EPOCHS}")
        print(f"  批次大小: {self.config.BATCH_SIZE}")
        print(f"  初始学习率: {self.config.LEARNING_RATE}")
        print(f"  早停耐心值: {self.config.EARLY_STOPPING_PATIENCE}")
        print(f"  训练样本: {len(train_loader.dataset)}")
        print(f"  验证样本: {len(val_loader.dataset)}")

        start_time = datetime.now()

        for epoch in range(self.config.NUM_EPOCHS):
            epoch_start = datetime.now()

            print(f"\n{'=' * 70}")
            print(f"📅 Epoch {epoch + 1}/{self.config.NUM_EPOCHS}")
            print(f"{'=' * 70}")

            # 训练
            train_loss, train_acc, train_f1 = self.train_epoch(train_loader)

            # 验证
            val_metrics = self.validate(val_loader)

            # 🔥 计算训练验证差距
            train_val_gap = train_acc - val_metrics['accuracy']
            self.history['train_val_gap'].append(train_val_gap)

            # 🔥 动态调整学习率
            self.scheduler.step(val_metrics['loss'])

            # 打印学习率更新信息
            current_lr = self.optimizer.param_groups[0]['lr']
            print(f"  当前学习率: {current_lr:.6f}")

            # 保存历史
            self.history['train_loss'].append(train_loss)
            self.history['train_acc'].append(train_acc)
            self.history['train_f1'].append(train_f1)
            self.history['val_loss'].append(val_metrics['loss'])
            self.history['val_acc'].append(val_metrics['accuracy'])
            self.history['val_f1'].append(val_metrics['f1'])
            self.history['val_precision'].append(val_metrics['precision'])
            self.history['val_recall'].append(val_metrics['recall'])
            self.history['val_kappa'].append(val_metrics['kappa'])
            self.history['learning_rate'].append(current_lr)
            self.history['epoch_times'].append((datetime.now() - epoch_start).total_seconds())

            # 保存类别指标
            for class_id, metrics in val_metrics['class_metrics'].items():
                self.history[f'class_{class_id}_f1'].append(metrics['f1'])
                self.history[f'class_{class_id}_recall'].append(metrics['recall'])

                # 更新最佳类别指标
                if metrics['f1'] > self.best_class_metrics[class_id]['f1']:
                    self.best_class_metrics[class_id]['f1'] = metrics['f1']
                    self.best_class_metrics[class_id]['recall'] = metrics['recall']

            # 打印结果
            print(f"\n📊 训练结果:")
            print(f"  损失: {train_loss:.4f} | 准确率: {train_acc:.4f} | F1: {train_f1:.4f}")

            print(f"\n📊 验证结果:")
            print(f"  损失: {val_metrics['loss']:.4f} | 准确率: {val_metrics['accuracy']:.4f}")
            print(f"  F1: {val_metrics['f1']:.4f} | Kappa: {val_metrics['kappa']:.4f}")
            print(f"  🔥 训练验证差距: {train_val_gap:.4f}")

            # 🔥 检查过拟合
            if train_val_gap > 0.3:  # 训练验证差距超过30%
                print(f"⚠️  警告：严重过拟合！训练验证差距: {train_val_gap:.4f}")

            # 打印类别指标
            print(f"\n📊 类别指标:")
            for class_id, metrics in val_metrics['class_metrics'].items():
                if metrics['support'] > 0:
                    print(f"  类别 {class_id}: {metrics['support']}样本 | "
                          f"P={metrics['precision']:.3f}, R={metrics['recall']:.3f}, F1={metrics['f1']:.3f}")

            # 检查是否是最佳模型
            current_val_acc = val_metrics['accuracy']

            # 🔥 修改：考虑训练验证差距的模型选择
            # 只有当验证准确率提升且过拟合不严重时才保存
            improvement = current_val_acc - self.best_val_acc
            if improvement > 0.005 and train_val_gap < 0.4:  # 要求0.5%提升且差距小于40%
                print(f"\n💾 发现更好模型: 准确率提升 {improvement:.4f}")
                self.best_val_acc = current_val_acc
                self.best_val_loss = val_metrics['loss']
                self.best_val_f1 = val_metrics['f1']
                self.best_model_state = copy.deepcopy(self.model.state_dict())

                # 保存最佳模型
                best_model_path = os.path.join(self.experiment_dir, 'best_model.pth')
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': self.best_model_state,
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'best_val_acc': self.best_val_acc,
                    'best_val_loss': self.best_val_loss,
                    'best_val_f1': self.best_val_f1,
                    'val_metrics': val_metrics,
                    'history': self.history,
                }, best_model_path)
                print(f"✅ 保存最佳模型到: {best_model_path}")
                print(f"  验证准确率: {current_val_acc:.4f}")
                print(f"  验证F1: {val_metrics['f1']:.4f}")
                print(f"  训练验证差距: {train_val_gap:.4f}")

            # 早停检查
            if self.early_stopping(current_val_acc):
                print(f"\n{'=' * 70}")
                print(f"🛑 在第 {epoch + 1} 轮触发早停")
                print(f"  最佳验证准确率: {self.best_val_acc:.4f}")
                print(f"  最佳验证F1: {self.best_val_f1:.4f}")
                print(f"  最终训练验证差距: {train_val_gap:.4f}")
                print(f"{'=' * 70}")
                break

            # 每5个epoch保存一次检查点
            if (epoch + 1) % 5 == 0:
                checkpoint_path = os.path.join(self.experiment_dir, f'checkpoint_epoch_{epoch + 1}.pth')
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': self.model.state_dict(),
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'val_acc': val_metrics['accuracy'],
                    'val_loss': val_metrics['loss'],
                    'val_f1': val_metrics['f1'],
                    'train_val_gap': train_val_gap,
                    'history': self.history,
                }, checkpoint_path)
                print(f"📁 保存检查点到: {checkpoint_path}")

            epoch_duration = (datetime.now() - epoch_start).total_seconds()
            print(f"\n⏱️  Epoch 耗时: {epoch_duration:.1f}s")

        # 训练完成
        total_time = (datetime.now() - start_time).total_seconds()

        print(f"\n{'=' * 70}")
        print(f"🎉 训练完成!")
        print(f"{'=' * 70}")

        # 加载最佳模型
        if self.best_model_state is not None:
            self.model.load_state_dict(self.best_model_state)
            print(f"📦 加载最佳模型权重 (准确率: {self.best_val_acc:.4f})")

        print(f"📈 最佳验证准确率: {self.best_val_acc:.4f}")
        print(f"📊 最佳验证F1: {self.best_val_f1:.4f}")
        print(f"📉 最佳验证损失: {self.best_val_loss:.4f}")
        print(f"⏱️  总训练时间: {total_time:.1f}s")
        print(f"📁 实验目录: {self.experiment_dir}")

        # 打印各个类别的最佳性能
        print(f"\n📊 各个类别最佳性能:")
        for class_id in range(4):
            print(f"  类别 {class_id}: "
                  f"最佳F1={self.best_class_metrics[class_id]['f1']:.4f}, "
                  f"最佳召回率={self.best_class_metrics[class_id]['recall']:.4f}")

        # 保存最终模型
        final_model_path = os.path.join(self.experiment_dir, 'final_model.pth')
        torch.save(self.model.state_dict(), final_model_path)
        print(f"💾 保存最终模型到: {final_model_path}")

        # 保存训练历史
        history_path = os.path.join(self.experiment_dir, 'training_history.pth')
        torch.save(self.history, history_path)

        # 保存历史为JSON
        history_json = {}
        for k, v in self.history.items():
            if isinstance(v, list) and len(v) > 0 and isinstance(v[0], np.ndarray):
                history_json[k] = [item.tolist() for item in v]
            elif isinstance(v, np.ndarray):
                history_json[k] = v.tolist()
            else:
                history_json[k] = v

        with open(os.path.join(self.experiment_dir, 'training_history.json'), 'w') as f:
            json.dump(history_json, f, indent=2)

        print(f"📊 保存训练历史到: {history_path}")

        # 绘制训练历史图表
        self._plot_training_history()
        print(f"📈 保存训练图表到: {os.path.join(self.experiment_dir, 'training_history.png')}")

        return self.history


def main():
    """主函数"""
    # 确保目录存在
    os.makedirs(config.SAVE_DIR, exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)

    print("🔧 初始化配置...")
    print(f"  图像目录: {config.IMAGE_DIR}")
    print(f"  标注目录: {config.ANNOTATION_DIR}")
    print(f"  保存目录: {config.SAVE_DIR}")
    print(f"  日志目录: {config.LOG_DIR}")
    print(f"  类别分布: {config.CLASS_COUNTS}")

    try:
        # 创建数据加载器
        print("\n📚 创建数据加载器...")
        train_loader, val_loader, dataset_info = create_data_loaders(config, batch_size=config.BATCH_SIZE)

        print(f"📊 数据加载器信息:")
        print(f"  总样本数: {dataset_info['total_samples']}")

        # 🔥 创建防过拟合的ResNet模型
        print("\n🏗️  创建防过拟合ResNet模型...")
        model = RetinaResNet(
            num_classes=config.NUM_CLASSES,
            pretrained=True,
            model_name='resnet18',  # 使用resnet18（复杂度适中）
            dropout_rate=0.6  # 🔥 更高的dropout率
        )

        # 打印模型摘要
        print("\n📋 模型结构摘要:")
        print(model)

        # 创建训练器
        print("\n⚙️  创建训练器...")
        trainer = Trainer(model, config)

        # 开始训练
        print("\n" + "=" * 70)
        print(f"🚀 开始训练防过拟合ResNet模型!")
        print("=" * 70)
        history = trainer.train(train_loader, val_loader)

        print("\n" + "=" * 70)
        print("🎊 训练成功完成!")
        print("=" * 70)

        # 打印最终总结
        if history:
            print(f"\n📊 训练总结:")
            print(f"  总轮数: {len(history['train_loss'])}")
            if history['val_acc']:
                print(f"  最佳验证准确率: {max(history['val_acc']):.4f}")
                print(f"  最佳验证F1分数: {max(history['val_f1']):.4f}")
                print(f"  最终验证准确率: {history['val_acc'][-1]:.4f}")
            if history['train_val_gap']:
                print(f"  最终训练验证差距: {history['train_val_gap'][-1]:.4f}")

        return history

    except Exception as e:
        print(f"\n❌ 训练过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    # 命令行参数支持
    import argparse

    parser = argparse.ArgumentParser(description='训练视网膜病变分类模型 (ResNet防过拟合版)')
    parser.add_argument('--epochs', type=int, default=50, help='训练轮数')
    parser.add_argument('--batch_size', type=int, default=8, help='批次大小')
    parser.add_argument('--lr', type=float, default=0.00005, help='学习率')  # 🔥 更低的学习率
    parser.add_argument('--device', type=str, choices=['cpu', 'cuda'], default='cpu', help='训练设备')
    parser.add_argument('--model', type=str, choices=['resnet18', 'resnet34', 'resnet50'],
                        default='resnet18', help='ResNet模型类型')
    parser.add_argument('--quick_test', action='store_true', help='快速测试模式')
    parser.add_argument('--dropout', type=float, default=0.6, help='Dropout率')

    args = parser.parse_args()

    # 更新配置
    config.NUM_EPOCHS = args.epochs
    config.BATCH_SIZE = args.batch_size
    config.LEARNING_RATE = args.lr
    config.DEVICE = args.device

    # 快速测试模式
    if args.quick_test:
        config.NUM_EPOCHS = 5
        config.BATCH_SIZE = 4
        config.LEARNING_RATE = 0.0001
        config.EARLY_STOPPING_PATIENCE = 3
        print("🔬 快速测试模式启用")
    else:
        config.EARLY_STOPPING_PATIENCE = 12

    print(f"🎯 训练配置:")
    print(f"  训练轮数: {config.NUM_EPOCHS}")
    print(f"  批次大小: {config.BATCH_SIZE}")
    print(f"  学习率: {config.LEARNING_RATE}")
    print(f"  设备: {config.DEVICE}")
    print(f"  模型类型: {args.model}")
    print(f"  Dropout率: {args.dropout}")
    print(f"  早停耐心值: {config.EARLY_STOPPING_PATIENCE}")

    # 运行训练
    try:
        # 创建数据加载器
        train_loader, val_loader, dataset_info = create_data_loaders(config, batch_size=config.BATCH_SIZE)

        print(f"📊 数据加载器信息:")
        print(f"  总样本数: {dataset_info['total_samples']}")

        # 创建ResNet模型
        print(f"\n🏗️  创建{args.model}模型 (dropout={args.dropout})...")
        model = RetinaResNet(
            num_classes=config.NUM_CLASSES,
            pretrained=True,
            model_name=args.model,
            dropout_rate=args.dropout
        )

        # 打印模型摘要
        print("\n📋 模型结构摘要:")
        print(model)

        # 创建训练器
        print("\n⚙️  创建训练器...")
        trainer = Trainer(model, config)

        # 开始训练
        print("\n" + "=" * 70)
        print(f"🚀 开始训练{args.model}视网膜病变分类模型!")
        print("=" * 70)
        history = trainer.train(train_loader, val_loader)

        print("\n" + "=" * 70)
        print("🎊 训练成功完成!")
        print("=" * 70)

        # 打印最终总结
        if history:
            print(f"\n📊 训练总结:")
            print(f"  总轮数: {len(history['train_loss'])}")
            if history['val_acc']:
                print(f"  最佳验证准确率: {max(history['val_acc']):.4f}")
                print(f"  最佳验证F1分数: {max(history['val_f1']):.4f}")
                print(f"  最终验证准确率: {history['val_acc'][-1]:.4f}")

    except Exception as e:
        print(f"\n❌ 训练过程中出现错误: {e}")
        import traceback

        traceback.print_exc()