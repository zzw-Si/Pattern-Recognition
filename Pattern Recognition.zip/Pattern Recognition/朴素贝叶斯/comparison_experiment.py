"""
对比实验：PCA、PCA+HOG、PCA+HOG+SMOTE
在不同PCA维度下的效果对比
"""

import numpy as np
import pandas as pd
from pathlib import Path
import cv2
from PIL import Image
from sklearn.decomposition import PCA
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from skimage.feature import hog as skimage_hog
from tqdm import tqdm
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


def load_data_and_images(images_dir, annotations_file):
    """加载标注数据和图像路径"""
    images_path = Path(images_dir)
    df = pd.read_excel(annotations_file, engine='openpyxl')
    
    image_paths = []
    labels = []
    base_dirs = list(images_path.glob("Base*"))
    
    for idx, row in df.iterrows():
        image_name = row['Image name']
        label = row['Retinopathy grade']
        
        for base_dir in base_dirs:
            image_path = base_dir / image_name
            if image_path.exists():
                image_paths.append(str(image_path))
                labels.append(label)
                break
    
    return image_paths, np.array(labels)


def extract_pixel_features(image_paths):
    """提取原始像素特征（用于PCA方法）"""
    features_list = []
    
    for img_path in tqdm(image_paths, desc="提取像素特征"):
        try:
            pil_img = Image.open(img_path)
            
            # 处理16位图像
            if pil_img.mode in ('I;16', 'I;16B', 'I;16L', 'I'):
                img_array = np.array(pil_img)
                if img_array.max() > 255:
                    img_array = ((img_array - img_array.min()) / (img_array.max() - img_array.min()) * 255).astype(np.uint8)
                else:
                    img_array = img_array.astype(np.uint8)
                
                if len(img_array.shape) == 2:
                    img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
                elif len(img_array.shape) == 3 and img_array.shape[2] == 1:
                    img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
                
                img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
            else:
                if pil_img.mode != 'RGB':
                    if pil_img.mode == 'RGBA':
                        rgb_img = Image.new('RGB', pil_img.size, (255, 255, 255))
                        rgb_img.paste(pil_img, mask=pil_img.split()[3])
                        pil_img = rgb_img
                    elif pil_img.mode == 'L':
                        pil_img = pil_img.convert('RGB')
                    else:
                        pil_img = pil_img.convert('RGB')
                
                img_array = np.array(pil_img)
                img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
            
            # 调整大小并展平
            img_resized = cv2.resize(img, (64, 64))  # 使用64x64以减少维度
            pixel_features = img_resized.flatten()
            features_list.append(pixel_features)
            
        except Exception as e:
            print(f"错误: 处理图像 {img_path}: {str(e)}")
            features_list.append(None)
    
    # 处理None值
    valid_features = [f for f in features_list if f is not None]
    if len(valid_features) == 0:
        raise ValueError("没有成功提取任何特征！")
    
    feature_dim = len(valid_features[0])
    for i, feat in enumerate(features_list):
        if feat is None:
            features_list[i] = np.zeros(feature_dim)
    
    return np.array(features_list)


def extract_hog_features(image_paths):
    """提取HOG特征"""
    features_list = []
    
    for img_path in tqdm(image_paths, desc="提取HOG特征"):
        try:
            pil_img = Image.open(img_path)
            
            # 处理16位图像
            if pil_img.mode in ('I;16', 'I;16B', 'I;16L', 'I'):
                img_array = np.array(pil_img)
                if img_array.max() > 255:
                    img_array = ((img_array - img_array.min()) / (img_array.max() - img_array.min()) * 255).astype(np.uint8)
                else:
                    img_array = img_array.astype(np.uint8)
                
                if len(img_array.shape) == 2:
                    img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
                elif len(img_array.shape) == 3 and img_array.shape[2] == 1:
                    img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
                
                img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
            else:
                if pil_img.mode != 'RGB':
                    if pil_img.mode == 'RGBA':
                        rgb_img = Image.new('RGB', pil_img.size, (255, 255, 255))
                        rgb_img.paste(pil_img, mask=pil_img.split()[3])
                        pil_img = rgb_img
                    elif pil_img.mode == 'L':
                        pil_img = pil_img.convert('RGB')
                    else:
                        pil_img = pil_img.convert('RGB')
                
                img_array = np.array(pil_img)
                img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
            
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            gray_resized = cv2.resize(gray, (128, 128))
            
            # 提取HOG特征
            hog_features = skimage_hog(
                gray_resized,
                orientations=9,
                pixels_per_cell=(8, 8),
                cells_per_block=(2, 2),
                block_norm='L2-Hys',
                feature_vector=True
            )
            
            features_list.append(hog_features)
            
        except Exception as e:
            print(f"错误: 处理图像 {img_path}: {str(e)}")
            features_list.append(None)
    
    # 处理None值
    valid_features = [f for f in features_list if f is not None]
    if len(valid_features) == 0:
        raise ValueError("没有成功提取任何特征！")
    
    feature_dim = len(valid_features[0])
    for i, feat in enumerate(features_list):
        if feat is None:
            features_list[i] = np.zeros(feature_dim)
    
    return np.array(features_list)


def evaluate_with_kfold(X, y, pca_components, use_smote=False, k_folds=5, verbose=False):
    """使用K折交叉验证评估模型，返回详细指标"""
    scaler = StandardScaler()
    pca = PCA(n_components=pca_components)
    classifier = GaussianNB()
    
    kfold = KFold(n_splits=k_folds, shuffle=True, random_state=42)
    fold_accuracies = []
    all_predictions = []
    all_true_labels = []
    
    for fold, (train_idx, test_idx) in enumerate(kfold.split(X), 1):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        # 标准化
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # PCA降维
        X_train_pca = pca.fit_transform(X_train_scaled)
        X_test_pca = pca.transform(X_test_scaled)
        
        # SMOTE（如果使用）
        if use_smote:
            try:
                smote = SMOTE(random_state=42)
                X_train_pca, y_train = smote.fit_resample(X_train_pca, y_train)
            except Exception as e:
                if verbose:
                    print(f"    第{fold}折 SMOTE警告: {str(e)}")
        
        # 训练和预测
        classifier.fit(X_train_pca, y_train)
        y_pred = classifier.predict(X_test_pca)
        accuracy = accuracy_score(y_test, y_pred)
        fold_accuracies.append(accuracy)
        
        all_predictions.extend(y_pred)
        all_true_labels.extend(y_test)
        
        if verbose:
            print(f"    第{fold}折准确率: {accuracy:.4f}")
    
    # 计算整体指标
    mean_accuracy = np.mean(fold_accuracies)
    std_accuracy = np.std(fold_accuracies)
    
    # 分类报告和混淆矩阵
    class_labels = sorted(set(y))
    report = classification_report(all_true_labels, all_predictions, 
                                  target_names=[f'等级{i}' for i in class_labels],
                                  output_dict=True, zero_division=0)
    cm = confusion_matrix(all_true_labels, all_predictions)
    
    return {
        'mean_accuracy': mean_accuracy,
        'std_accuracy': std_accuracy,
        'fold_accuracies': fold_accuracies,
        'classification_report': report,
        'confusion_matrix': cm,
        'all_predictions': all_predictions,
        'all_true_labels': all_true_labels
    }


def run_comparison_experiment(images_dir, annotations_file, pca_dimensions=[50, 100, 150, 200], k_folds=5):
    """运行对比实验"""
    print("=" * 60)
    print("对比实验：PCA、PCA+HOG、PCA+HOG+SMOTE")
    print("=" * 60)
    
    # 1. 加载数据
    print("\n步骤1: 加载数据")
    image_paths, labels = load_data_and_images(images_dir, annotations_file)
    print(f"成功加载 {len(image_paths)} 张图像")
    print(f"标签分布: {pd.Series(labels).value_counts().sort_index().to_dict()}")
    
    # 2. 提取特征
    print("\n步骤2: 提取特征")
    print("提取像素特征（用于PCA方法）...")
    pixel_features = extract_pixel_features(image_paths)
    print(f"像素特征维度: {pixel_features.shape}")
    
    print("\n提取HOG特征（用于PCA+HOG和PCA+HOG+SMOTE方法）...")
    hog_features = extract_hog_features(image_paths)
    print(f"HOG特征维度: {hog_features.shape}")
    
    # 3. 运行实验
    print("\n步骤3: 运行对比实验")
    results = {
        'PCA': {'mean': [], 'std': [], 'details': []},
        'PCA+HOG': {'mean': [], 'std': [], 'details': []},
        'PCA+HOG+SMOTE': {'mean': [], 'std': [], 'details': []}
    }
    
    for pca_dim in pca_dimensions:
        print(f"\n{'='*60}")
        print(f"PCA维度: {pca_dim}")
        print(f"{'='*60}")
        
        # 方法1: PCA（直接对像素特征）
        print("\n方法1: PCA")
        print("-" * 60)
        eval_result = evaluate_with_kfold(pixel_features, labels, pca_dim, use_smote=False, k_folds=k_folds, verbose=True)
        results['PCA']['mean'].append(eval_result['mean_accuracy'])
        results['PCA']['std'].append(eval_result['std_accuracy'])
        results['PCA']['details'].append(eval_result)
        print(f"\n平均准确率: {eval_result['mean_accuracy']:.4f} ± {eval_result['std_accuracy']:.4f}")
        print(f"各折准确率: {[f'{acc:.4f}' for acc in eval_result['fold_accuracies']]}")
        print("\n分类报告:")
        print(classification_report(eval_result['all_true_labels'], eval_result['all_predictions'],
                                  target_names=[f'等级{i}' for i in sorted(set(labels))]))
        print("混淆矩阵:")
        print(eval_result['confusion_matrix'])
        
        # 方法2: PCA+HOG
        print(f"\n{'='*60}")
        print("方法2: PCA+HOG")
        print("-" * 60)
        eval_result = evaluate_with_kfold(hog_features, labels, pca_dim, use_smote=False, k_folds=k_folds, verbose=True)
        results['PCA+HOG']['mean'].append(eval_result['mean_accuracy'])
        results['PCA+HOG']['std'].append(eval_result['std_accuracy'])
        results['PCA+HOG']['details'].append(eval_result)
        print(f"\n平均准确率: {eval_result['mean_accuracy']:.4f} ± {eval_result['std_accuracy']:.4f}")
        print(f"各折准确率: {[f'{acc:.4f}' for acc in eval_result['fold_accuracies']]}")
        print("\n分类报告:")
        print(classification_report(eval_result['all_true_labels'], eval_result['all_predictions'],
                                  target_names=[f'等级{i}' for i in sorted(set(labels))]))
        print("混淆矩阵:")
        print(eval_result['confusion_matrix'])
        
        # 方法3: PCA+HOG+SMOTE
        print(f"\n{'='*60}")
        print("方法3: PCA+HOG+SMOTE")
        print("-" * 60)
        eval_result = evaluate_with_kfold(hog_features, labels, pca_dim, use_smote=True, k_folds=k_folds, verbose=True)
        results['PCA+HOG+SMOTE']['mean'].append(eval_result['mean_accuracy'])
        results['PCA+HOG+SMOTE']['std'].append(eval_result['std_accuracy'])
        results['PCA+HOG+SMOTE']['details'].append(eval_result)
        print(f"\n平均准确率: {eval_result['mean_accuracy']:.4f} ± {eval_result['std_accuracy']:.4f}")
        print(f"各折准确率: {[f'{acc:.4f}' for acc in eval_result['fold_accuracies']]}")
        print("\n分类报告:")
        print(classification_report(eval_result['all_true_labels'], eval_result['all_predictions'],
                                  target_names=[f'等级{i}' for i in sorted(set(labels))]))
        print("混淆矩阵:")
        print(eval_result['confusion_matrix'])
    
    # 4. 绘制结果
    print("\n步骤4: 绘制对比结果")
    plot_comparison_results(results, pca_dimensions)
    
    # 5. 打印汇总结果
    print("\n" + "=" * 60)
    print("实验结果汇总")
    print("=" * 60)
    for method in results:
        print(f"\n{method}:")
        for i, dim in enumerate(pca_dimensions):
            print(f"  PCA维度 {dim}: {results[method]['mean'][i]:.4f} ± {results[method]['std'][i]:.4f}")
    
    return results


def plot_comparison_results(results, pca_dimensions):
    """绘制对比折线图"""
    fig, ax = plt.subplots(figsize=(10, 6))
    
    methods = ['PCA', 'PCA+HOG', 'PCA+HOG+SMOTE']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
    markers = ['o', 's', '^']
    
    for i, method in enumerate(methods):
        means = results[method]['mean']
        stds = results[method]['std']
        
        ax.errorbar(
            pca_dimensions, 
            means, 
            yerr=stds,
            label=method,
            color=colors[i],
            marker=markers[i],
            markersize=8,
            linewidth=2,
            capsize=5,
            capthick=2,
            alpha=0.8
        )
    
    ax.set_xlabel('PCA维度', fontsize=12)
    ax.set_ylabel('准确率', fontsize=12)
    ax.set_title('不同方法在不同PCA维度下的准确率对比', fontsize=14, fontweight='bold')
    ax.set_xticks(pca_dimensions)
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.legend(loc='best', fontsize=10)
    ax.set_ylim([0, 1])
    
    plt.tight_layout()
    plt.savefig('comparison_results.png', dpi=300, bbox_inches='tight')
    print("对比结果图已保存到: comparison_results.png")
    plt.close()


if __name__ == "__main__":
    # 设置路径
    images_dir = "视网膜病变识别/images"
    annotations_file = "merged_annotations.xlsx"
    
    # 运行对比实验
    results = run_comparison_experiment(
        images_dir=images_dir,
        annotations_file=annotations_file,
        pca_dimensions=[50, 100, 150, 200],
        k_folds=5
    )

