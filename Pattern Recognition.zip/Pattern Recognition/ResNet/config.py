# config.py - 优化版

import torch
import os
import numpy as np


class Config:
    # 数据路径
    IMAGE_DIR = "images"  # 包含BaseXX文件夹的目录
    ANNOTATION_DIR = "annotation of images"  # 包含.xls文件的文件夹

    # 模型参数
    NUM_CLASSES = 4  # Retinopathy grade: 0, 1, 2, 3
    INPUT_CHANNELS = 3  # RGB图像
    IMAGE_SIZE = 256  # 调整为256×256

    # 原始图像尺寸
    ORIGINAL_HEIGHT = 1488
    ORIGINAL_WIDTH = 2240

    # Excel表头信息（根据你的图片描述）
    EXCEL_HEADERS = {
        'image_name': 'Image name',
        'department': 'Ophthalmologic department',
        'grade': 'Retinopathy grade',
        'edema_risk': 'Risk of macular edema'
    }

    # 🔥 训练参数优化
    BATCH_SIZE = 8  # 保持较小批次，适合CPU训练
    NUM_EPOCHS = 150  # 增加训练轮数
    LEARNING_RATE = 0.0005  # 降低初始学习率
    WEIGHT_DECAY = 0.001  # 增加权重衰减，防止过拟合

    # 类别权重（根据你的数据分布）
    CLASS_COUNTS = [547, 153, 246, 254]  # 类别0-3的样本数

    # 🔥 改进类别权重计算
    @property
    def CLASS_WEIGHTS(self):
        """计算更合理的类别权重"""
        class_counts = torch.tensor(self.CLASS_COUNTS, dtype=torch.float32)
        total_samples = class_counts.sum()
        # 逆频率加权（更激进）
        weights = total_samples / (len(class_counts) * class_counts)
        # 归一化
        weights = weights / weights.sum() * len(class_counts)
        return weights.tolist()

    # 🔥 添加用于Focal Loss的alpha参数
    @property
    def FOCAL_ALPHA(self):
        """用于Focal Loss的alpha参数"""
        class_counts = torch.tensor(self.CLASS_COUNTS, dtype=torch.float32)
        total_samples = class_counts.sum()
        # 逆频率作为alpha
        alpha = total_samples / (len(class_counts) * class_counts)
        # 归一化到0-1范围
        alpha = alpha / alpha.sum()
        return alpha.tolist()

    # 数据增强参数 - 增强版
    AUGMENTATION_PROB = 0.5
    ROTATION_RANGE = 15
    BRIGHTNESS_RANGE = [0.8, 1.2]
    CONTRAST_RANGE = [0.8, 1.2]

    # 🔥 添加医学图像特定的增强参数
    CLAHE_CLIP_LIMIT = 2.0  # 对比度增强
    NOISE_VAR_LIMIT = (10.0, 50.0)  # 高斯噪声
    COARSE_DROPOUT_MAX_HOLES = 8  # 随机遮挡
    RANDOM_CROP_SCALE = (0.8, 1.0)  # 随机裁剪

    # 设备 - 使用字符串而不是torch.device对象（避免JSON序列化问题）
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

    # 获取torch.device对象的方法
    @property
    def torch_device(self):
        """获取torch.device对象"""
        return torch.device(self.DEVICE)

    # 保存路径
    SAVE_DIR = "checkpoints"
    LOG_DIR = "logs"
    RESULTS_DIR = "results"

    # 🔥 早停优化
    EARLY_STOPPING_PATIENCE = 20  # 增加早停耐心值
    MIN_DELTA = 0.001
    LR_PATIENCE = 5  # 学习率降低耐心值
    MIN_LR_FACTOR = 0.01  # 最小学习率因子

    # 验证集比例
    VALIDATION_SPLIT = 0.2
    TEST_SPLIT = 0.1

    # 随机种子
    SEED = 42

    # 🔥 梯度累积步数（根据batch_size自动计算）
    @property
    def GRADIENT_ACCUMULATION_STEPS(self):
        """计算梯度累积步数"""
        return max(1, 32 // self.BATCH_SIZE)

    # 🔥 OneCycleLR参数
    @property
    def ONECYCLE_MAX_LR(self):
        """OneCycleLR最大学习率"""
        # CPU训练使用适中的学习率，GPU可以使用更高的学习率
        if self.DEVICE == "cuda":
            return self.LEARNING_RATE * 3.0
        else:
            return self.LEARNING_RATE * 1.5

    @property
    def ONECYCLE_PCT_START(self):
        """OneCycleLR预热比例"""
        return 0.3

    # 🔥 学习率预热轮数
    WARMUP_EPOCHS = 5

    def __init__(self):
        os.makedirs(self.SAVE_DIR, exist_ok=True)
        os.makedirs(self.LOG_DIR, exist_ok=True)
        os.makedirs(self.RESULTS_DIR, exist_ok=True)

        # 设置随机种子
        self._set_random_seed()

        # 打印配置信息
        self.print_config()

    def _set_random_seed(self):
        """设置随机种子"""
        torch.manual_seed(self.SEED)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(self.SEED)
            torch.cuda.manual_seed_all(self.SEED)
        np.random.seed(self.SEED)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    def print_config(self):
        """打印配置信息"""
        print("=" * 60)
        print("⚙️ 训练配置")
        print("=" * 60)
        print(f"📊 数据配置:")
        print(f"  图像目录: {self.IMAGE_DIR}")
        print(f"  标注目录: {self.ANNOTATION_DIR}")
        print(f"  图像尺寸: {self.IMAGE_SIZE}×{self.IMAGE_SIZE}")

        print(f"\n📊 类别分布:")
        total_samples = sum(self.CLASS_COUNTS)
        for i, count in enumerate(self.CLASS_COUNTS):
            percentage = count / total_samples * 100
            print(f"  类别 {i}: {count} 张 ({percentage:.1f}%)")

        # 计算类别不平衡度
        max_count = max(self.CLASS_COUNTS)
        min_count = min(self.CLASS_COUNTS)
        imbalance_ratio = max_count / min_count
        print(f"  类别不平衡度: {imbalance_ratio:.1f}:1")

        print(f"\n⚙️ 训练参数:")
        print(f"  批次大小: {self.BATCH_SIZE}")
        print(f"  训练轮数: {self.NUM_EPOCHS}")
        print(f"  学习率: {self.LEARNING_RATE}")
        print(f"  权重衰减: {self.WEIGHT_DECAY}")
        print(f"  设备: {self.DEVICE}")

        print(f"\n📈 优化参数:")
        print(f"  梯度累积步数: {self.GRADIENT_ACCUMULATION_STEPS}")
        print(f"  OneCycle最大LR: {self.ONECYCLE_MAX_LR}")
        print(f"  学习率预热轮数: {self.WARMUP_EPOCHS}")
        print(f"  早停耐心值: {self.EARLY_STOPPING_PATIENCE}")
        print(f"  学习率降低耐心值: {self.LR_PATIENCE}")

        print(f"\n📊 类别权重:")
        for i, weight in enumerate(self.CLASS_WEIGHTS):
            print(f"  类别 {i}: {weight:.3f}")
        print("=" * 60)

    def get_class_weights_tensor(self, device=None):
        """获取用于损失函数的类别权重张量"""
        if device is None:
            device = self.torch_device
        weights = torch.tensor(self.CLASS_WEIGHTS, dtype=torch.float32)
        return weights.to(device)

    def get_focal_alpha_tensor(self, device=None):
        """获取用于Focal Loss的alpha张量"""
        if device is None:
            device = self.torch_device
        alpha = torch.tensor(self.FOCAL_ALPHA, dtype=torch.float32)
        return alpha.to(device)

    @property
    def weighted_loss_weights(self):
        """用于加权交叉熵损失的权重"""
        weights = self.get_class_weights_tensor()
        return weights

    def get_optimizer_config(self, model):
        """获取优化器配置"""
        if self.DEVICE == 'cpu':
            # CPU训练：SGD通常更稳定
            optimizer_config = {
                'type': 'SGD',
                'lr': self.LEARNING_RATE * 0.5,  # CPU上学习率小一点
                'momentum': 0.9,
                'weight_decay': self.WEIGHT_DECAY,
                'nesterov': True
            }
        else:
            # GPU训练：AdamW
            optimizer_config = {
                'type': 'AdamW',
                'lr': self.LEARNING_RATE,
                'weight_decay': self.WEIGHT_DECAY * 2.0,  # 增加权重衰减
                'betas': (0.9, 0.999),
                'eps': 1e-8
            }
        return optimizer_config

    def get_scheduler_config(self, optimizer, train_loader_length):
        """获取学习率调度器配置"""
        total_steps = self.NUM_EPOCHS * train_loader_length
        scheduler_config = {
            'type': 'OneCycleLR',
            'max_lr': self.ONECYCLE_MAX_LR,
            'total_steps': total_steps,
            'pct_start': self.ONECYCLE_PCT_START,
            'anneal_strategy': 'cos',
            'div_factor': 25.0,
            'final_div_factor': 10000.0
        }
        return scheduler_config

    def get_data_augmentation_config(self):
        """获取数据增强配置"""
        return {
            'horizontal_flip_prob': 0.5,
            'vertical_flip_prob': 0.3,
            'rotate_limit': self.ROTATION_RANGE,
            'rotate_prob': 0.5,
            'random_crop_scale': self.RANDOM_CROP_SCALE,
            'random_crop_prob': 0.3,
            'brightness_limit': 0.2,
            'contrast_limit': 0.2,
            'brightness_contrast_prob': 0.5,
            'clahe_clip_limit': self.CLAHE_CLIP_LIMIT,
            'clahe_prob': 0.3,
            'gauss_noise_var_limit': self.NOISE_VAR_LIMIT,
            'gauss_noise_prob': 0.2,
            'coarse_dropout_max_holes': self.COARSE_DROPOUT_MAX_HOLES,
            'coarse_dropout_prob': 0.3,
            'normalize_mean': [0.485, 0.456, 0.406],
            'normalize_std': [0.229, 0.224, 0.225]
        }


# 创建配置实例
config = Config()